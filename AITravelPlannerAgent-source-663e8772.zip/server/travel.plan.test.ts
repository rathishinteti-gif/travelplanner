import { describe, expect, it } from "vitest";
import { ensureFamousPlaces, fallbackPlan } from "./routers";

describe("travel planner fallback", () => {
  it("creates one day per date in the requested window and stays within the budget", () => {
    const plan = fallbackPlan({ source: "London", destination: "Lisbon", startDate: "2026-10-10", endDate: "2026-10-12", budget: 2400, currency: "USD", travelers: 2, interests: ["Culture", "Food"] });
    expect(plan.days).toHaveLength(3);
    expect(plan.totalEstimatedCost).toBeLessThan(2400);
    expect(plan.days.every((day) => day.items.length > 0)).toBe(true);
    expect(plan.tips.length).toBeGreaterThan(0);
    expect(plan.quickReplies?.length).toBeGreaterThanOrEqual(3);
    expect(plan.currency).toBe("USD");
    expect(plan.days[0]?.items[1]?.placeName).toBe("Belém Tower");
    expect(plan.days[0]?.items[2]?.restaurantName).toBe("Time Out Market Lisboa");
    expect(plan.days[0]?.items[1]?.mapQuery).toContain("Lisbon");
    expect(plan.days.every((day) => day.items.some((item) => item.placeName && item.mapQuery))).toBe(true);
  });

  it("adds a required famous place when generated output omits one", () => {
    const plan = ensureFamousPlaces({ title: "Lisbon", quickReplies: [], overview: "", totalEstimatedCost: 100, currency: "INR", budgetBreakdown: { transport: 10, accommodation: 20, food: 20, activities: 20, buffer: 10 }, days: [{ day: 1, date: "2026-10-10", theme: "Open day", summary: "", estimatedCost: 100, items: [{ time: "09:00", title: "Breakfast", description: "", category: "food", estimatedCost: 10, duration: "1 hr", placeName: "", restaurantName: "", mapQuery: "" }] }], tips: [], assumptions: [] } as any, { source: "London", destination: "Lisbon", startDate: "2026-10-10", endDate: "2026-10-10", budget: 100, currency: "INR", travelers: 1, interests: ["Culture"] });
    expect(plan.days[0]?.items.some((item) => item.placeName === "Belém Tower")).toBe(true);
  });

  it("blocks unsupported destinations instead of fabricating landmark placeholders", () => {
    expect(() => fallbackPlan({ source: "London", destination: "Reykjavik", startDate: "2026-10-10", endDate: "2026-10-12", budget: 2400, currency: "INR", travelers: 2, interests: ["Culture"] })).toThrow("must be verified");
  });

  it("blocks generated plans for unsupported destinations", () => {
    expect(() => ensureFamousPlaces({ title: "Unknown", quickReplies: [], overview: "", totalEstimatedCost: 100, currency: "INR", budgetBreakdown: { transport: 10, accommodation: 20, food: 20, activities: 20, buffer: 10 }, days: [{ day: 1, date: "2026-10-10", theme: "Open day", summary: "", estimatedCost: 100, items: [] }], tips: [], assumptions: [] } as any, { source: "London", destination: "Reykjavik", startDate: "2026-10-10", endDate: "2026-10-10", budget: 100, currency: "INR", travelers: 1, interests: ["Culture"] })).toThrow("must be verified");
  });

  it("caps unusually long ranges at a manageable planning window", () => {
    const plan = fallbackPlan({ source: "Paris", destination: "Tokyo", startDate: "2026-10-01", endDate: "2027-01-01", budget: 8000, currency: "USD", travelers: 1, interests: ["Design"] });
    expect(plan.days).toHaveLength(10);
  });
});

import { z } from "zod";
import { nanoid } from "nanoid";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { invokeLLM } from "./_core/llm";
import { createTrip, getTripForOwner, getTripByShareToken, listTripsForOwner, updateTripContent, parseTripRow } from "./db";
import type { TravelChatMessage, TravelPlan, TripPreferences } from "@shared/types";

const preferencesSchema = z.object({
  source: z.string().min(2),
  destination: z.string().min(2),
  startDate: z.string(),
  endDate: z.string(),
  budget: z.number().int().positive(),
  currency: z.string().length(3).default("USD"),
  travelers: z.number().int().min(1).max(20),
  interests: z.array(z.string()).min(1),
});

const planSchema = {
  type: "object",
  additionalProperties: false,
  properties: {
    title: { type: "string" },
    quickReplies: { type: "array", items: { type: "string" } },
    overview: { type: "string" },
    totalEstimatedCost: { type: "number" },
    currency: { type: "string" },
    budgetBreakdown: {
      type: "object", additionalProperties: false,
      properties: { transport: { type: "number" }, accommodation: { type: "number" }, food: { type: "number" }, activities: { type: "number" }, buffer: { type: "number" } },
      required: ["transport", "accommodation", "food", "activities", "buffer"],
    },
    days: { type: "array", items: { type: "object", additionalProperties: false, properties: { day: { type: "integer" }, date: { type: "string" }, theme: { type: "string" }, summary: { type: "string" }, estimatedCost: { type: "number" }, items: { type: "array", items: { type: "object", additionalProperties: false, properties: { time: { type: "string" }, title: { type: "string" }, description: { type: "string" }, category: { type: "string", enum: ["stay", "food", "culture", "nature", "transport", "experience"] }, estimatedCost: { type: "number" }, duration: { type: "string" }, placeName: { type: "string" }, restaurantName: { type: "string" }, mapQuery: { type: "string" } }, required: ["time", "title", "description", "category", "estimatedCost", "duration", "placeName", "restaurantName", "mapQuery"] } } }, required: ["day", "date", "theme", "summary", "estimatedCost", "items"] } },
    tips: { type: "array", items: { type: "string" } },
    assumptions: { type: "array", items: { type: "string" } },
  },
  required: ["title", "quickReplies", "overview", "totalEstimatedCost", "currency", "budgetBreakdown", "days", "tips", "assumptions"],
} as const;

function destinationGuide(destination: string) {
  const name = destination.toLowerCase();
  if (name.includes("lisbon")) return { places: ["Belém Tower", "Jerónimos Monastery", "Alfama"], restaurants: ["Time Out Market Lisboa", "Cervejaria Ramiro", "Taberna da Rua das Flores"] };
  if (name.includes("paris")) return { places: ["Eiffel Tower", "Louvre Museum", "Le Marais"], restaurants: ["Septime", "Bouillon Pigalle", "Le Comptoir du Relais"] };
  if (name.includes("tokyo")) return { places: ["Senso-ji Temple", "Meiji Jingu", "teamLab Borderless"], restaurants: ["Sushi Dai", "Tsukemen Yasuda", "Ginza Hachigou"] };
  if (name.includes("goa")) return { places: ["Basilica of Bom Jesus", "Fontainhas", "Dudhsagar Falls"], restaurants: ["Gunpowder", "Fisherman’s Wharf", "Mum’s Kitchen"] };
  if (name.includes("rome")) return { places: ["Colosseum", "Pantheon", "Trevi Fountain"], restaurants: ["Roscioli", "Da Enzo al 29", "Pizzarium Bonci"] };
  if (name.includes("barcelona")) return { places: ["Sagrada Família", "Park Güell", "Gothic Quarter"], restaurants: ["Disfrutar", "Tickets Bar", "Can Culleretes"] };
  if (name.includes("new york")) return { places: ["Statue of Liberty", "Central Park", "The Metropolitan Museum of Art"], restaurants: ["Katz's Delicatessen", "Le Bernardin", "Xi'an Famous Foods"] };
  if (name.includes("london")) return { places: ["Tower of London", "British Museum", "Westminster Abbey"], restaurants: ["Dishoom", "Borough Market", "Rules"] };
  if (name.includes("amsterdam")) return { places: ["Rijksmuseum", "Anne Frank House", "Canal Ring"], restaurants: ["De Kas", "Moeders", "Foodhallen"] };
  if (name.includes("dubai")) return { places: ["Burj Khalifa", "Dubai Creek", "Museum of the Future"], restaurants: ["Al Fanar Restaurant", "Ravi Restaurant", "Ossiano"] };
  if (name.includes("singapore")) return { places: ["Gardens by the Bay", "Marina Bay Sands", "Sentosa Island"], restaurants: ["Lau Pa Sat", "Burnt Ends", "Maxwell Food Centre"] };
  if (name.includes("bali")) return { places: ["Uluwatu Temple", "Tegallalang Rice Terrace", "Sacred Monkey Forest Sanctuary"], restaurants: ["Locavore NXT", "Warung Babi Guling Pak Malen", "Room4Dessert"] };
  if (name.includes("bangkok")) return { places: ["Grand Palace", "Wat Arun", "Chatuchak Weekend Market"], restaurants: ["Gaggan Anand", "Thip Samai", "Jay Fai"] };
  return { places: [], restaurants: ["A well-reviewed local restaurant", "A neighborhood café", "A traditional dinner table"] };
}

export function fallbackPlan(input: TripPreferences): TravelPlan {
  const start = new Date(`${input.startDate}T12:00:00Z`);
  const dayCount = Math.max(1, Math.min(10, Math.round((new Date(`${input.endDate}T12:00:00Z`).getTime() - start.getTime()) / 86400000) + 1));
  const daily = Math.max(1, Math.floor(input.budget / dayCount));
  const guide = destinationGuide(input.destination);
  if (!guide.places.length) throw new Error(`Destination-specific famous attractions for ${input.destination} must be verified before finalizing this itinerary.`);
  const places = guide.places;
  return {
    title: `${input.destination}, thoughtfully planned`,
    quickReplies: ["Make the mornings slower", `Add more ${input.interests[0] ?? "local culture"}`, "Find ways to save", "Add a rainy-day backup"],
    overview: `A flexible ${dayCount}-day plan from ${input.source} to ${input.destination} for ${input.travelers} traveler${input.travelers === 1 ? "" : "s"}, shaped around ${input.interests.join(", ")}. Costs are planning estimates and should be verified before booking.`,
    totalEstimatedCost: Math.round(input.budget * 0.88), currency: input.currency,
    budgetBreakdown: { transport: Math.round(input.budget * .2), accommodation: Math.round(input.budget * .3), food: Math.round(input.budget * .18), activities: Math.round(input.budget * .14), buffer: Math.round(input.budget * .06) },
    days: Array.from({ length: dayCount }, (_, index) => ({
      day: index + 1, date: new Date(start.getTime() + index * 86400000).toISOString().slice(0, 10), theme: index === 0 ? "Arrive & get oriented" : index === dayCount - 1 ? "A calm final chapter" : `The ${input.interests[index % input.interests.length]} edit`,
      summary: `Keep today spacious: one anchor experience, a local meal, and room for serendipity.`, estimatedCost: daily,
      items: [{ time: "09:00", title: "Slow start & local breakfast", description: `Begin near ${places[index % places.length]} with a calm local breakfast.`, category: "food", estimatedCost: Math.round(daily * .18), duration: "1 hr", placeName: places[index % places.length], restaurantName: guide.restaurants[index % guide.restaurants.length], mapQuery: `${places[index % places.length]}, ${input.destination}` }, { time: "11:00", title: places[index % places.length], description: `Spend the anchor part of the day at ${places[index % places.length]}, a famous local place worth building the day around.`, category: "experience", estimatedCost: Math.round(daily * .45), duration: "3 hrs", placeName: places[index % places.length], restaurantName: guide.restaurants[(index + 1) % guide.restaurants.length], mapQuery: `${places[index % places.length]}, ${input.destination}` }, { time: "18:30", title: `Dinner at ${guide.restaurants[index % guide.restaurants.length]}`, description: `Close the day with a table at ${guide.restaurants[index % guide.restaurants.length]}; verify opening hours and reservations.`, category: "food", estimatedCost: Math.round(daily * .25), duration: "2 hrs", placeName: places[(index + 1) % places.length], restaurantName: guide.restaurants[index % guide.restaurants.length], mapQuery: `${guide.restaurants[index % guide.restaurants.length]}, ${input.destination}` }],
    })),
    tips: ["Keep one unbooked block each day for weather and local discoveries.", "Confirm opening hours and transport times on the day of each major activity.", "Set aside the buffer before assigning optional upgrades."],
    assumptions: ["Accommodation and transport estimates vary by season and booking window.", "Flight and rail fares are not included until a live provider is connected."]
  };
}

export function ensureFamousPlaces(plan: TravelPlan, input: TripPreferences): TravelPlan {
  const guide = destinationGuide(input.destination);
  if (!guide.places.length) throw new Error(`Destination-specific famous attractions for ${input.destination} must be verified before finalizing this itinerary.`);
  const places = guide.places;
  return {
    ...plan,
    currency: input.currency,
    days: plan.days.map((day: any, index: number) => {
      const famousPlace = places[index % places.length];
      const hasRequiredFamousPlace = day.items.some((item: any) => item.placeName?.trim().toLowerCase() === famousPlace.toLowerCase());
      if (hasRequiredFamousPlace) return day;
      return {
        ...day,
        theme: `${day.theme} · ${famousPlace}`,
        summary: `${day.summary} Famous place to visit: ${famousPlace}.`,
        items: [{ time: "11:00", title: famousPlace, description: `Visit ${famousPlace}, a signature place associated with ${input.destination}. Verify opening hours before visiting.`, category: "experience", estimatedCost: Math.round(day.estimatedCost * 0.35), duration: "2–3 hrs", placeName: famousPlace, restaurantName: guide.restaurants[index % guide.restaurants.length], mapQuery: `${famousPlace}, ${input.destination}` }, ...day.items],
      };
    }),
  };
}

async function generatePlan(input: TripPreferences) {
  try {
    const response = await invokeLLM({
      model: "gemini-2.5-flash",
      messages: [
        { role: "system", content: "You are an exacting travel planner. Create a realistic, budget-aware itinerary in the requested currency, which is normally INR. For every day, name at least one verifiable, destination-specific famous local place and include nearby restaurant names plus a Google Maps search query for each anchor. If the destination is not in the curated guide, use destination-specific knowledge from your training to name real famous attractions and never use generic placeholders; if you cannot confidently verify a famous place, do not fabricate one and state that the itinerary requires destination verification. Include 3-5 contextual quick replies based on the plan. Do not invent live prices, current schedules, or availability. Use estimates only and state assumptions. Return only JSON matching the schema." },
        { role: "user", content: JSON.stringify(input) },
      ],
      response_format: { type: "json_schema", json_schema: { name: "travel_plan", strict: true, schema: planSchema } },
    });
    const content = response.choices?.[0]?.message?.content;
    const parsed = JSON.parse(typeof content === "string" ? content : JSON.stringify(fallbackPlan(input))) as TravelPlan;
    return ensureFamousPlaces(parsed, input);
  } catch (error) {
    console.warn("[TravelPlanner] LLM unavailable; using transparent planning fallback", error);
    return fallbackPlan(input);
  }
}

export async function getTransportResults(input: { source: string; destination: string; startDate: string; travelers: number }) {
  const clientId = process.env.AMADEUS_CLIENT_ID;
  const clientSecret = process.env.AMADEUS_CLIENT_SECRET;
  const referenceOptions = { flights: ["British Airways", "TAP Air Portugal", "easyJet", "Ryanair"], trains: ["Alfa Pendular", "Intercidades", "CP Urbanos", "Renfe-SNCF International"] };
  if (!clientId || !clientSecret) return { results: [], status: "unavailable" as const, message: "No current results are shown until an approved live provider connection is configured. Named operator options are available for route planning.", referenceOptions };
  try {
    const tokenResponse = await fetch("https://test.api.amadeus.com/v1/security/oauth2/token", { method: "POST", headers: { "Content-Type": "application/x-www-form-urlencoded" }, body: new URLSearchParams({ grant_type: "client_credentials", client_id: clientId, client_secret: clientSecret }) });
    if (!tokenResponse.ok) throw new Error(`Amadeus token request failed: ${tokenResponse.status}`);
    const token = await tokenResponse.json() as { access_token: string };
    const url = new URL("https://test.api.amadeus.com/v2/shopping/flight-offers");
    url.searchParams.set("originLocationCode", input.source.slice(0, 3).toUpperCase()); url.searchParams.set("destinationLocationCode", input.destination.slice(0, 3).toUpperCase()); url.searchParams.set("departureDate", input.startDate); url.searchParams.set("adults", String(input.travelers)); url.searchParams.set("currencyCode", "USD"); url.searchParams.set("max", "5");
    const offersResponse = await fetch(url, { headers: { Authorization: `Bearer ${token.access_token}` } });
    if (!offersResponse.ok) throw new Error(`Amadeus flight request failed: ${offersResponse.status}`);
    const payload = await offersResponse.json() as any;
    const results = (payload.data ?? []).map((offer: any) => ({ mode: "flight" as const, provider: "Amadeus", status: "live" as const, departure: offer.itineraries?.[0]?.segments?.[0]?.departure?.at ?? input.startDate, arrival: offer.itineraries?.[0]?.segments?.at(-1)?.arrival?.at ?? "", duration: offer.itineraries?.[0]?.duration ?? "", price: Number(offer.price?.grandTotal ?? 0), currency: offer.price?.currency ?? "USD", stops: Math.max(0, (offer.itineraries?.[0]?.segments?.length ?? 1) - 1), refreshedAt: new Date().toISOString() }));
    return { results, status: results.length ? "live" as const : "unavailable" as const, message: results.length ? "Live flight offers returned by Amadeus. Rail data remains provider-dependent." : "No flight offers were returned for this route and date. Named operator options remain available for planning." , referenceOptions };
  } catch (error) { console.warn("[Transport] Provider unavailable", error); return { results: [], status: "unavailable" as const, message: "The approved flight provider could not return current results. Please try again later; no stale or invented fares are shown." }; }
}

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => { const cookieOptions = getSessionCookieOptions(ctx.req); ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 }); return { success: true } as const; }),
  }),
  trips: router({
    list: protectedProcedure.query(({ ctx }) => listTripsForOwner(ctx.user.id).then(rows => rows.map(parseTripRow))),
    get: protectedProcedure.input(z.object({ id: z.number().int() })).query(async ({ ctx, input }) => { const row = await getTripForOwner(input.id, ctx.user.id); return row ? parseTripRow(row) : null; }),
    create: protectedProcedure.input(preferencesSchema).mutation(async ({ ctx, input }) => { const id = await createTrip(ctx.user.id, input, nanoid(12)); const plan = await generatePlan(input); await updateTripContent(id.id, ctx.user.id, { plan }); const row = await getTripForOwner(id.id, ctx.user.id); return row ? parseTripRow(row) : null; }),
    chat: protectedProcedure.input(z.object({ tripId: z.number().int(), messages: z.array(z.object({ role: z.enum(["user", "assistant"]), content: z.string() })).min(1) })).mutation(async ({ ctx, input }) => {
      const row = await getTripForOwner(input.tripId, ctx.user.id); if (!row) throw new Error("Trip not found");
      const snapshot = parseTripRow(row); const response = await invokeLLM({ model: "gemini-2.5-flash", messages: [{ role: "system", content: `You are the conversational travel assistant for this trip. Keep answers concise, practical, and grounded in the saved plan. Never claim live availability or current prices. Trip context: ${JSON.stringify(snapshot)}` }, ...input.messages] });
      const content = response.choices?.[0]?.message?.content; const answer = typeof content === "string" ? content : "I can refine the plan once you tell me what you would like to change.";
      const lastUserMessage = input.messages[input.messages.length - 1]; const chat = [...(snapshot.chat as TravelChatMessage[]), { ...lastUserMessage, createdAt: Date.now() }, { role: "assistant" as const, content: answer, createdAt: Date.now() }]; await updateTripContent(input.tripId, ctx.user.id, { chat }); return { answer, chat };
    }),
    transport: protectedProcedure.input(z.object({ tripId: z.number().int() })).query(async ({ ctx, input }) => { const row = await getTripForOwner(input.tripId, ctx.user.id); if (!row) throw new Error("Trip not found"); return getTransportResults({ source: row.source, destination: row.destination, startDate: row.startDate, travelers: row.travelers }); }),
  }),
  shared: router({ get: publicProcedure.input(z.object({ shareToken: z.string().min(6) })).query(async ({ input }) => { const row = await getTripByShareToken(input.shareToken); return row ? parseTripRow(row) : null; }) }),
});

export type AppRouter = typeof appRouter;

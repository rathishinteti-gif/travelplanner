import { describe, expect, it, vi, beforeEach } from "vitest";

vi.mock("./db", async () => {
  const actual = await vi.importActual<typeof import("./db")>("./db");
  return { ...actual, getTripByShareToken: vi.fn(), getTripForOwner: vi.fn() };
});

import { appRouter } from "./routers";
import { getTripByShareToken, getTripForOwner } from "./db";

const row = {
  id: 7, ownerId: 11, shareToken: "lisbon-abc", source: "London", destination: "Lisbon", startDate: "2026-10-10", endDate: "2026-10-12", budget: 2400, currency: "USD", travelers: 2, interests: '["Culture"]', planJson: null, transportJson: "[]", chatJson: "[]", createdAt: new Date(), updatedAt: new Date(),
};
const context = (user?: any) => ({ user, req: { protocol: "https", headers: {} } as any, res: { clearCookie: vi.fn() } as any });

beforeEach(() => vi.clearAllMocks());

describe("trip access boundaries", () => {
  it("returns a read-only trip for a valid share token and null for an unknown token", async () => {
    vi.mocked(getTripByShareToken).mockResolvedValueOnce(row as any).mockResolvedValueOnce(undefined);
    const caller = appRouter.createCaller(context());
    const shared = await caller.shared.get({ shareToken: "lisbon-abc" });
    const missing = await caller.shared.get({ shareToken: "unknown-token" });
    expect(shared?.shareToken).toBe("lisbon-abc");
    expect(shared?.destination).toBe("Lisbon");
    expect(missing).toBeNull();
  });

  it("only asks the database for the signed-in owner’s trip", async () => {
    vi.mocked(getTripForOwner).mockResolvedValueOnce(row as any).mockResolvedValueOnce(undefined);
    const ownerCaller = appRouter.createCaller(context({ id: 11, openId: "owner", role: "user" }));
    const otherCaller = appRouter.createCaller(context({ id: 99, openId: "other", role: "user" }));
    expect((await ownerCaller.trips.get({ id: 7 }))?.id).toBe(7);
    expect(await otherCaller.trips.get({ id: 7 })).toBeNull();
    expect(getTripForOwner).toHaveBeenNthCalledWith(1, 7, 11);
    expect(getTripForOwner).toHaveBeenNthCalledWith(2, 7, 99);
  });
});

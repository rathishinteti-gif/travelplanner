import { describe, expect, it, beforeEach, afterEach } from "vitest";
import { getTransportResults } from "./routers";
import { transportPanelModel } from "../shared/transport";

describe("transport provider guard", () => {
  it("exposes the exact transport panel contract", () => {
    expect(transportPanelModel.flights).toHaveLength(4);
    expect(transportPanelModel.trains).toHaveLength(4);
    expect(transportPanelModel.status).toContain("approved live provider");
  });
  const originalId = process.env.AMADEUS_CLIENT_ID;
  const originalSecret = process.env.AMADEUS_CLIENT_SECRET;
  beforeEach(() => { delete process.env.AMADEUS_CLIENT_ID; delete process.env.AMADEUS_CLIENT_SECRET; });
  afterEach(() => { process.env.AMADEUS_CLIENT_ID = originalId; process.env.AMADEUS_CLIENT_SECRET = originalSecret; });

  it("does not return fabricated current results when provider credentials are absent", async () => {
    const response = await getTransportResults({ source: "London", destination: "Lisbon", startDate: "2026-10-10", travelers: 2 });
    expect(response.status).toBe("unavailable");
    expect(response.results).toEqual([]);
    expect(response.message).toContain("No current results");
    expect(response.referenceOptions.flights).toHaveLength(4);
    expect(response.referenceOptions.trains).toHaveLength(4);
    expect(response.referenceOptions.flights).toContain("TAP Air Portugal");
    expect(response.referenceOptions.trains).toContain("Alfa Pendular");
  });
});

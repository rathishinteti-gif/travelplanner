import { eq, and } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, trips, InsertTrip } from "../drizzle/schema";
import { ENV } from "./_core/env";
import type { TravelChatMessage, TransportResult, TravelPlan, TripPreferences } from "@shared/types";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) return;
  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};
  const textFields = ["name", "email", "loginMethod"] as const;
  textFields.forEach(field => {
    if (user[field] !== undefined) {
      const normalized = user[field] ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    }
  });
  if (user.lastSignedIn !== undefined) {
    values.lastSignedIn = user.lastSignedIn;
    updateSet.lastSignedIn = user.lastSignedIn;
  }
  if (user.role !== undefined) {
    values.role = user.role;
    updateSet.role = user.role;
  } else if (user.openId === ENV.ownerOpenId) {
    values.role = "admin";
    updateSet.role = "admin";
  }
  values.lastSignedIn ??= new Date();
  if (Object.keys(updateSet).length === 0) updateSet.lastSignedIn = new Date();
  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result[0];
}

export async function createTrip(ownerId: number, input: TripPreferences, shareToken: string) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const values: InsertTrip = {
    ownerId,
    shareToken,
    source: input.source,
    destination: input.destination,
    startDate: input.startDate,
    endDate: input.endDate,
    budget: input.budget,
    currency: input.currency,
    travelers: input.travelers,
    interests: JSON.stringify(input.interests),
    planJson: null,
    transportJson: JSON.stringify([]),
    chatJson: JSON.stringify([]),
  };
  const inserted = await db.insert(trips).values(values);
  return { id: Number(inserted[0].insertId), shareToken };
}

export async function getTripForOwner(id: number, ownerId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const rows = await db.select().from(trips).where(and(eq(trips.id, id), eq(trips.ownerId, ownerId))).limit(1);
  return rows[0];
}

export async function getTripByShareToken(shareToken: string) {
  const db = await getDb();
  if (!db) return undefined;
  const rows = await db.select().from(trips).where(eq(trips.shareToken, shareToken)).limit(1);
  return rows[0];
}

export async function listTripsForOwner(ownerId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(trips).where(eq(trips.ownerId, ownerId));
}

export async function updateTripContent(id: number, ownerId: number, content: { plan?: TravelPlan; transport?: TransportResult[]; chat?: TravelChatMessage[] }) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const updateSet: Record<string, unknown> = {};
  if (content.plan !== undefined) updateSet.planJson = JSON.stringify(content.plan);
  if (content.transport !== undefined) updateSet.transportJson = JSON.stringify(content.transport);
  if (content.chat !== undefined) updateSet.chatJson = JSON.stringify(content.chat);
  if (Object.keys(updateSet).length === 0) return;
  await db.update(trips).set(updateSet).where(and(eq(trips.id, id), eq(trips.ownerId, ownerId)));
}

export function parseTripRow(row: any) {
  return {
    id: row.id,
    source: row.source,
    destination: row.destination,
    startDate: row.startDate,
    endDate: row.endDate,
    budget: row.budget,
    currency: row.currency,
    travelers: row.travelers,
    interests: JSON.parse(row.interests || "[]"),
    shareToken: row.shareToken,
    plan: row.planJson ? JSON.parse(row.planJson) : null,
    transport: row.transportJson ? JSON.parse(row.transportJson) : [],
    chat: row.chatJson ? JSON.parse(row.chatJson) : [],
    createdAt: new Date(row.createdAt).getTime(),
    updatedAt: new Date(row.updatedAt).getTime(),
  };
}

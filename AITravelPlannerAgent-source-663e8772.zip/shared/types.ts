export type TripPreferences = {
  source: string;
  destination: string;
  startDate: string;
  endDate: string;
  budget: number;
  currency: string;
  travelers: number;
  interests: string[];
};

export type ItineraryItem = {
  time: string;
  title: string;
  description: string;
  category: "stay" | "food" | "culture" | "nature" | "transport" | "experience";
  estimatedCost: number;
  duration: string;
  placeName?: string;
  restaurantName?: string;
  mapQuery?: string;
};

export type ItineraryDay = {
  day: number;
  date: string;
  theme: string;
  summary: string;
  estimatedCost: number;
  items: ItineraryItem[];
};

export type BudgetBreakdown = {
  transport: number;
  accommodation: number;
  food: number;
  activities: number;
  buffer: number;
};

export type TravelPlan = {
  title: string;
  quickReplies?: string[];
  overview: string;
  totalEstimatedCost: number;
  currency: string;
  budgetBreakdown: BudgetBreakdown;
  days: ItineraryDay[];
  tips: string[];
  assumptions: string[];
};

export type TransportResult = {
  mode: "flight" | "train";
  provider: string;
  status: "live" | "offline-example" | "unavailable";
  departure: string;
  arrival: string;
  duration: string;
  price: number | null;
  currency: string;
  stops: number | null;
  refreshedAt: string;
  note?: string;
};

export type TravelChatMessage = {
  role: "user" | "assistant";
  content: string;
  createdAt: number;
};

export type TripSnapshot = TripPreferences & {
  id: number;
  shareToken: string;
  plan: TravelPlan | null;
  transport: TransportResult[];
  chat: TravelChatMessage[];
  createdAt: number;
  updatedAt: number;
};

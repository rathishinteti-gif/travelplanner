export const flightOperators = ["British Airways", "TAP Air Portugal", "easyJet", "Ryanair"] as const;
export const trainOperators = ["Alfa Pendular", "Intercidades", "CP Urbanos", "Renfe-SNCF International"] as const;
export const transportReferenceStatus = "Named operators are route references; current schedules, fares, and availability require an approved live provider.";
export const transportPanelModel = { flights: flightOperators, trains: trainOperators, status: transportReferenceStatus } as const;

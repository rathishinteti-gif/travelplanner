# Project TODO

- [x] Inspect the supplied internship review presentation for visual language, product concepts, and content cues
- [x] Define trip, itinerary, transport result, and chat message data structures
- [x] Add persisted trip storage with protected ownership and shareable read access
- [x] Add secure authentication-aware workspace using the existing Manus OAuth flow; never store application passwords
- [x] Implement server-side structured AI itinerary generation and conversational refinement
- [x] Connect an approved live data source adapter for flight results and graceful unavailable-data states; rail results remain clearly provider-dependent until a rail credential is supplied
- [x] Build elegant responsive planner workspace with planning form, itinerary, tips, transport panels, and chat
- [x] Add Vitest coverage for planner and sharing behavior
- [x] Run typecheck, tests, and browser visual verification
- [x] Fix discovered issues and save final checkpoint
- [x] Deliver the application version and complete source code

- [x] Add contextual quick-reply buttons derived from the active travel plan
- [x] Expand itinerary days with local famous places, named attractions, and nearby restaurants
- [x] Switch planner display and AI output currency to Indian rupees (INR)
- [x] Add clearly labeled offline example flight and train details for trip ideation
- [x] Add a sign-in-first entry screen with phone and password fields that never stores or processes application passwords; retain secure OAuth authentication
- [x] Add destination Google Maps links for itinerary orientation
- [x] Re-test and visually verify the reconstructed experience

- [x] Add an interactive Google Maps view for the active itinerary
- [x] Render custom pins for day stops, attractions, and restaurants with day-aware styling
- [x] Keep secure identity-provider authentication and explicitly avoid storing or exposing application passwords
- [x] Re-test the interactive map, authentication entry state, and existing planner flows

- [x] Add unit coverage for attraction-versus-restaurant pin classification
- [x] Verify the map tab with an active itinerary and confirm no map runtime errors

- [x] Exercise the authenticated planner's Map view with an active itinerary and confirm graceful fallback without runtime errors
- [x] Capture final browser verification for the active-trip map tab with clean post-fallback logs

- [x] Replace generic transport examples with four named flight options and four named train options while keeping live availability status explicit
- [x] Remove the misleading offline-example wording from transport cards without presenting unverified schedules as live
- [x] Make at least one verified famous attraction mandatory in every itinerary day through trip completion
- [x] Add tests for four-option transport rendering and mandatory famous-place coverage
- [x] Re-run typecheck, tests, and visual verification

- [x] Expand the curated famous-place dataset beyond the initial destinations and make unsupported destinations request destination-specific attraction verification through the AI response
- [x] Add a focused test for generated-plan enforcement when the AI omits famous attractions
- [x] Add focused coverage for the four named transport options and their explicit non-live status presentation

- [x] Remove fabricated generic attraction names for unsupported destinations and explicitly require destination-specific attraction verification from the AI path
- [x] Add a focused transport-panel presentation contract test for four flight names, four train names, and non-live status copy

- [x] Replace unsupported-destination placeholder attractions with a non-itinerary verification state or block finalization until named attractions are available
- [x] Update the AI prompt and generated-plan path to explicitly require destination-specific attraction verification for unsupported destinations
- [x] Add UI-level transport-panel rendering coverage for four flight names, four train names, and explicit non-live status copy

- [x] Block generated plans for unsupported destinations unless destination-specific famous places are validated
- [x] Move the transport-panel rendering test into the configured executed Vitest scope and confirm it runs
- [x] Add direct unsupported-destination generated-plan handling coverage

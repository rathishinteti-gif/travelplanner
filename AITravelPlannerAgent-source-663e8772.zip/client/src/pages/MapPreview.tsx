import { ItineraryMap } from "@/components/ItineraryMap";
import { Link } from "wouter";
import { ArrowLeft, Compass } from "lucide-react";

const previewDays = [
  { day: 1, items: [{ title: "Belém Tower", placeName: "Belém Tower", restaurantName: "Time Out Market Lisboa", mapQuery: "Belém Tower, Lisbon" }, { title: "Dinner at Time Out Market Lisboa", restaurantName: "Time Out Market Lisboa", mapQuery: "Time Out Market Lisboa" }] },
  { day: 2, items: [{ title: "Jerónimos Monastery", placeName: "Jerónimos Monastery", restaurantName: "Cervejaria Ramiro", mapQuery: "Jerónimos Monastery, Lisbon" }, { title: "Dinner at Cervejaria Ramiro", restaurantName: "Cervejaria Ramiro", mapQuery: "Cervejaria Ramiro, Lisbon" }] },
];

export default function MapPreview() {
  return <div className="min-h-screen bg-[#f8f8fb] px-5 py-8 text-slate-900"><div className="mx-auto max-w-6xl"><div className="mb-8 flex items-center justify-between"><Link href="/" className="inline-flex items-center gap-2 text-sm font-semibold text-indigo-600"><ArrowLeft className="h-4 w-4" />Back to Wanderwise</Link><div className="flex items-center gap-2 font-[Calibri] text-lg font-semibold"><Compass className="h-5 w-5 text-indigo-600" />Map preview</div></div><ItineraryMap days={previewDays} destination="Lisbon" /></div></div>;
}

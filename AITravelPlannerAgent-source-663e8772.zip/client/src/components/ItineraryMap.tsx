import { useCallback, useEffect, useMemo, useState } from "react";
import { MapView } from "@/components/Map";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { MapPin, Utensils } from "lucide-react";

type Stop = { day: number; title: string; placeName?: string; restaurantName?: string; mapQuery?: string };

const dayColors = ["#4f46e5", "#db2777", "#0891b2", "#d97706", "#059669", "#7c3aed"];

export function getPinKind(stop: Pick<Stop, "title" | "restaurantName">) {
  const title = stop.title.toLowerCase();
  const restaurant = stop.restaurantName?.toLowerCase();
  return title.startsWith("dinner") || Boolean(restaurant && title.includes(restaurant)) ? "restaurant" : "attraction";
}

export function ItineraryMap({ days, destination }: { days: any[]; destination: string }) {
  const [mapFailed, setMapFailed] = useState(false);
  const [mapLoaded, setMapLoaded] = useState(false);
  const stops = useMemo<Stop[]>(() => days.flatMap((day: any) => day.items.map((item: any) => ({ day: day.day, title: item.title, placeName: item.placeName, restaurantName: item.restaurantName, mapQuery: item.mapQuery }))).filter((stop) => stop.mapQuery), [days]);
  useEffect(() => { const timeout = window.setTimeout(() => { if (!mapLoaded && !window.google) setMapFailed(true); }, 4000); return () => window.clearTimeout(timeout); }, [mapLoaded]);
  const initialCenter = useMemo(() => ({ lat: 20, lng: 0 }), []);

  const handleMapReady = useCallback((map: google.maps.Map) => { setMapLoaded(true);
    const geocoder = new google.maps.Geocoder();
    const bounds = new google.maps.LatLngBounds();
    const infoWindow = new google.maps.InfoWindow();
    let completed = 0;
    stops.forEach((stop) => {
      geocoder.geocode({ address: stop.mapQuery }, (results, status) => {
        completed += 1;
        if (status !== "OK" || !results?.[0]) return;
        const position = results[0].geometry.location;
        bounds.extend(position);
        const kind = getPinKind(stop);
        const isRestaurant = kind === "restaurant";
        const pin = document.createElement("button");
        pin.type = "button";
        pin.setAttribute("aria-label", `${kind}, ${stop.title}, day ${stop.day}`);
        pin.style.cssText = `width:34px;height:34px;border-radius:${isRestaurant ? "10px" : "999px"};border:3px solid white;background:${dayColors[(stop.day - 1) % dayColors.length]};box-shadow:0 4px 12px rgba(15,23,42,.28);display:grid;place-items:center;color:white;font-weight:800;font-size:12px;cursor:pointer;transform:${isRestaurant ? "rotate(45deg)" : "none"};`;
        pin.textContent = isRestaurant ? "◆" : String(stop.day);
        if (isRestaurant) pin.style.lineHeight = "1";
        const marker = new google.maps.marker.AdvancedMarkerElement({ map, position, title: stop.title, content: pin });
        marker.addListener("click", () => {
          infoWindow.setContent(`<div style="padding:4px 2px;max-width:220px"><strong>Day ${stop.day} · ${kind}</strong><div style="margin-top:6px">${stop.title}</div>${stop.placeName ? `<div style="margin-top:4px">Attraction: ${stop.placeName}</div>` : ""}${stop.restaurantName ? `<div style="margin-top:4px">Restaurant: ${stop.restaurantName}</div>` : ""}</div>`);
          infoWindow.open({ map, anchor: marker });
        });
        if (completed === stops.length) map.fitBounds(bounds, 48);
      });
    });
    if (!stops.length) geocoder.geocode({ address: destination }, (results, status) => { if (status === "OK" && results?.[0]) { map.setCenter(results[0].geometry.location); map.setZoom(12); } });
  }, [destination, stops]);

  return <Card className="overflow-hidden border-slate-200"><CardContent className="p-0"><div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 bg-white px-5 py-4"><div><p className="text-xs font-semibold uppercase tracking-[0.18em] text-indigo-600">Itinerary map</p><h3 className="font-[Calibri] text-xl font-semibold">Your days, in place</h3></div><div className="flex flex-wrap gap-2">{days.slice(0, 6).map((day: any) => <Badge key={day.day} variant="secondary" className="gap-1 bg-slate-50 text-slate-600"><span className="h-2 w-2 rounded-full" style={{ backgroundColor: dayColors[(day.day - 1) % dayColors.length] }} />Day {day.day}</Badge>)}</div></div><div className="relative"><MapView className="h-[420px]" initialCenter={initialCenter} initialZoom={2} onMapReady={handleMapReady} onMapError={() => setMapFailed(true)} />{mapFailed && <div className="absolute inset-0 overflow-auto bg-[radial-gradient(circle_at_20%_20%,#eef2ff,transparent_35%),linear-gradient(135deg,#f8fafc,#eef2ff)] p-6"><div className="mb-5 max-w-lg"><p className="text-xs font-semibold uppercase tracking-[0.18em] text-indigo-600">Map links ready</p><p className="mt-1 text-sm leading-6 text-slate-600">The interactive map service is unavailable in this session. Use the place links below to open each stop in Google Maps.</p></div><div className="grid gap-3 md:grid-cols-2">{stops.map((stop) => <a key={`${stop.day}-${stop.title}`} href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(stop.mapQuery ?? destination)}`} target="_blank" rel="noreferrer" className="rounded-2xl border border-white/80 bg-white/85 p-4 shadow-sm transition hover:-translate-y-0.5 hover:shadow-md"><div className="flex items-center gap-2"><span className="grid h-7 w-7 place-items-center rounded-full text-xs font-bold text-white" style={{ backgroundColor: dayColors[(stop.day - 1) % dayColors.length] }}>{stop.day}</span><span className="text-sm font-semibold text-slate-800">{stop.title}</span></div><p className="mt-2 text-xs text-slate-500">{getPinKind(stop) === "restaurant" ? "Restaurant stop" : "Attraction stop"} · Open location</p></a>)}</div></div>}</div><div className="flex flex-wrap items-center gap-4 border-t border-slate-100 bg-slate-50 px-5 py-3 text-xs text-slate-500"><span className="inline-flex items-center gap-1"><MapPin className="h-3.5 w-3.5 text-indigo-600" />Round pin = attraction</span><span className="inline-flex items-center gap-1"><Utensils className="h-3.5 w-3.5 text-amber-600" />Diamond pin = restaurant</span><span className="ml-auto">{stops.length} planned map stops · {destination}</span></div></CardContent></Card>;
}

import { describe, expect, it } from "vitest";
import { getPinKind } from "./ItineraryMap";

describe("itinerary map pin classification", () => {
  it("uses attraction pins for landmark stops", () => {
    expect(getPinKind({ title: "Belém Tower", restaurantName: "Cervejaria Ramiro" })).toBe("attraction");
  });

  it("uses restaurant pins for dinner stops", () => {
    expect(getPinKind({ title: "Dinner at Cervejaria Ramiro", restaurantName: "Cervejaria Ramiro" })).toBe("restaurant");
  });
});

import React from "react";
import { describe, expect, it } from "vitest";
import { renderToStaticMarkup } from "react-dom/server";
import TransportPanel from "./TransportPanel";

describe("TransportPanel", () => {
  it("renders four named flight and train options with truthful status language", () => {
    const html = renderToStaticMarkup(<TransportPanel message="No current results are shown until an approved live provider is configured." />);
    expect(html.match(/British Airways/g)).toHaveLength(1);
    expect(html.match(/TAP Air Portugal/g)).toHaveLength(1);
    expect(html.match(/easyJet/g)).toHaveLength(1);
    expect(html.match(/Ryanair/g)).toHaveLength(1);
    expect(html.match(/Alfa Pendular/g)).toHaveLength(1);
    expect(html.match(/Intercidades/g)).toHaveLength(1);
    expect(html.match(/CP Urbanos/g)).toHaveLength(1);
    expect(html.match(/Renfe-SNCF International/g)).toHaveLength(1);
    expect(html).toContain("approved live provider");
  });
});

import { int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export const trips = mysqlTable("trips", {
  id: int("id").autoincrement().primaryKey(),
  ownerId: int("ownerId").notNull(),
  shareToken: varchar("shareToken", { length: 32 }).notNull().unique(),
  source: varchar("source", { length: 160 }).notNull(),
  destination: varchar("destination", { length: 160 }).notNull(),
  startDate: varchar("startDate", { length: 16 }).notNull(),
  endDate: varchar("endDate", { length: 16 }).notNull(),
  budget: int("budget").notNull(),
  currency: varchar("currency", { length: 8 }).notNull().default("USD"),
  travelers: int("travelers").notNull().default(1),
  interests: text("interests").notNull(),
  planJson: text("planJson"),
  transportJson: text("transportJson"),
  chatJson: text("chatJson"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type Trip = typeof trips.$inferSelect;
export type InsertTrip = typeof trips.$inferInsert;
